// pages/shopCart/shopCart.js
const utils = require('./../../utils/util.js'); //接口和key文件
const httpUtil  = require('./../../utils/httpUtil.js'); 
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
    orderBaseUrl:app.globalData.orderBaseUrl,
    showCustomPopup:false,
    isEmpty:false,
    tipImg:"/images/emptyCart.png",
    productList:[],//购物车
    cost:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      productList:app.globalData.productList
    })
    if(this.data.productList.length!=0){
        this.setData({
          isEmpty:false
        })
    }else{
      this.setData({
        isEmpty:true
      })
    }
    this.costAll(this.data.productList)
    // console.log(this.data.productList)
  },
  //去结算
  handle(){
      this.setData({
        showCustomPopup:true
      })
  },
  //关闭
  maskClick(){
    this.setData({
      showCustomPopup:false
    })
  },
  //确定就餐人数
  confirm(e){
    let number = e.detail;
    console.log(number)
    this.setData({
      showCustomPopup:false
    })
     wx.navigateTo({
       url: this.data.orderBaseUrl+'/pages/settlement/settlement',
     })
  },
  //去点餐
  goList(){
    wx.redirectTo({
      url: this.data.orderBaseUrl+'/pages/home/home',
    })
  },
   //减少购物车的商品
   decrease(e){
    console.log('当前商品',e.currentTarget.dataset)
       let goodsItem =  utils.deepClone(e.currentTarget.dataset.itemname); //点击的商品
       goodsItem.count = goodsItem.count>0?--goodsItem.count:0;//改变数量
       // 如果当前商品数量为0则删除该商品
       if(goodsItem.count>0){
         this.changeNumber(goodsItem)
       }else{
         this.deleteGoods(goodsItem)
       }
  },
   //增加购物车的商品
   add(e){
       console.log('当前商品',e.currentTarget.dataset)
       let goodsItem =  utils.deepClone(e.currentTarget.dataset.itemname); //点击的商品
       goodsItem.count = ++goodsItem.count; //增加数量
       this.changeNumber(goodsItem)
   },
   //改变购物车商品数量
 changeNumber(goodsItem){
   let productList = this.data.productList;
    productList[0].cartList.forEach((item,index)=>{
        if(item.item_code==goodsItem.item_code){
          productList[0].cartList[index].count = goodsItem.count;
        }
    })
    this.setData({
       productList:productList
    })
    app.globalData.productList = productList;
    this.costAll(productList);//计算总价
},
//如果该商品数量为0则删除购物车该商品，如果购物车中该店铺的所有商品为0，则删除整个店铺
deleteGoods(goodsItem){
  let productList = this.data.productList;
    console.log(productList)
    productList[0].cartList.forEach((item,index)=>{
      if(item.item_code==goodsItem.item_code){
        productList[0].cartList.splice(index,1)
      }
  })
  if( productList[0].cartList.length==0){
     productList = [];
     this.setData({
       isEmpty:true
     })
  }else{
    this.setData({
      isEmpty:false
    })
  }
  this.setData({
    productList:productList
 })
 app.globalData.productList = productList;
  this.costAll(productList);//计算总价
  
},
  //初始化购物车列表
  initCartList(){
      
  },
    // 计算总价
   costAll(productList){
      let cost = 0;
      if (this.data.productList.length != 0) {
        let cartList = this.data.productList[0].cartList;
        if (cartList.length != 0) {
          cartList.forEach(item => {
              cost += item.count * item.item_price;
          });
        }
    } 
        this.setData({
          cost: cost.toFixed(2)
        })
        return cost.toFixed(2);
    },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})