const app = getApp()
const utils = require('./../../utils/util.js'); //接口和key文件
const httpUtil  = require('./../../utils/httpUtil.js'); 
// pages/order/order.js
Page({
  //右侧分类的高度累加数组
  //比如：[洗车数组的高度，洗车+汽车美容的高度，洗车+汽车美容+精品的高度，...]
  heightArr: [], //右侧各个元素距离顶部距离的数组
    // // [160, 320, 1140, 1300, 1570, 1840, 2000]
    //  // 160：洗车标题高度50px，item的高度110，洗车只有一个item，所以50+110*1=160px;
    //  // 320: 汽车美容标题高度50px，只有一个item，再加上洗车的高度，所以50+110*1+160=320px;
  //记录scroll-view滚动过程中距离顶部的高度
  heightLeftArr:[],//左侧距离的高度
  distance: 0,  //右侧到顶部的距离
  distanceLeft:0,//左侧到顶部的距离

  /**
   * 页面的初始数据
   */

  /**
   * 页面的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
    orderBaseUrl:app.globalData.orderBaseUrl,
    footerHeight: app.globalData.footerHeight,//底部的高度
    currentLeft: 0, //左侧选中的下标
    selectId: "item0",  //当前显示的元素id
    scrollTop: 0, //到顶部的距离
    height:0,//获取整个屏幕的高度
    headHeight:0,//获取头部的高度
    leftMenuHight:0,//左侧每个元素的高度
    leftscrollTop:0,//左侧滚动的距离
    serviceTypes: [
      {
        type:"粉类主食",
        typeId:1,
        services:[
          {
            id:11,
            name:'红烧牛肉面',
            label:'',
            count:1,
            price:'32.00'
          },
          {
            id:12,
            name:'番茄牛肉面',
            label:'',
            count:1,
            price:'32.00'
          }
        ]
      },
      {
        type:"盖饭类",
        typeId:2,
        services:[
          {
            id:21,
            name:'牛肉饭',
            label:'',
            count:1,
            price:'32.00'
          },
          {
            id:22,
            name:'鸡腿饭',
            label:'',
            count:1,
            price:'32.00'
          }
        ]
      },
      {
        type:"凉拌类",
        typeId:3,
        services:[
          {
            id:31,
            name:'凉皮',
            label:'',
            count:1,
            price:'32.00'
          },
          {
            id:32,
            name:'海带',
            label:'',
            count:1,
            price:'32.00'
          }
        ]
      },
      {
        type:"烧烤类",
        typeId:4,
        services:[
          {
            id:41,
            name:'羊肉串',
            label:'',
            count:1,
            price:'32.00'
          },
          {
            id:42,
            name:'烤鸡翅',
            label:'',
            count:1,
            price:'32.00'
          }
        ]
      },
      {
        type:"饮品类",
        typeId:5,
        services:[
          {
            id:51,
            name:'可口可乐',
            label:'',
            count:1,
            price:'32.00'
          },
          {
            id:52,
            name:'雪碧',
            label:'',
            count:1,
            price:'32.00'
          }
        ]
      }
    ], //项目列表数据
    proData:{},
    sub_menus:[],
    shopCode:4000,
    shop_name:"",//店铺名称
     proData1: {
        "id": 4000,
        "shopCode": "4000",
        "name": "航站楼食堂超市",
        "address": "大兴机场航站楼",
        "mobile": "010-222222",
        "phone": "15201612449",
        "distance": 0.0,
        "logo": "/staff-file/3@3x.jpg",
    },
    sub_menus1: [
      {
          "sub_menu_id": 1,
          "sub_menu_name": "米面粮油",
          "sub_menu_code":"101",
          "sub_menu_img":"",
          "items": [
              {
                  "item_code": 1,
                  "storeCode": "food03",
                  "categoryId": 1,
                  "category": null,
                  "item_name": "五得利富强粉",
                  "introduction": "",
                  "item_price": 36.0,
                  "discountPrice": 36.0,
                  "specification": "1*5kg",
                  "direction": null,
                  "searchKey": "五得利富强粉",
                  "stockCount": 9,
                  "saleCount": 55,
                  "headPic": "/staff-file/imageArt001.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 2,
                  "storeCode": "food03",
                  "categoryId": 1,
                  "category": null,
                  "item_name": "五得利特精粉",
                  "introduction": "",
                  "item_price": 37.0,
                  "discountPrice": 37.0,
                  "specification": "1*5kg",
                  "direction": null,
                  "searchKey": "五得利特精粉",
                  "stockCount": 12,
                  "saleCount": 57,
                  "headPic": "/staff-file/imageArt002.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 4,
                  "storeCode": "food03",
                  "categoryId": 1,
                  "category": null,
                  "item_name": "鲁花花生油",
                  "introduction": "",
                  "item_price": 182.0,
                  "discountPrice": 182.0,
                  "specification": "1桶*5L+500ml酱油",
                  "direction": null,
                  "searchKey": "鲁花花生油",
                  "stockCount": 39,
                  "saleCount": 51,
                  "headPic": "/staff-file/imageArt004.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 6,
                  "storeCode": "food03",
                  "categoryId": 1,
                  "category": null,
                  "item_name": "金龙鱼非转大豆油",
                  "introduction": "",
                  "item_price": 76.0,
                  "discountPrice": 76.0,
                  "specification": "1桶*5L",
                  "direction": null,
                  "searchKey": "金龙鱼非转大豆油",
                  "stockCount": 3,
                  "saleCount": 52,
                  "headPic": "/staff-file/imageArt006.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 8,
                  "storeCode": "food03",
                  "categoryId": 1,
                  "category": null,
                  "item_name": "五常稻花香（简单稻里）",
                  "introduction": "",
                  "item_price": 105.0,
                  "discountPrice": 105.0,
                  "specification": "1袋*5kg",
                  "direction": null,
                  "searchKey": "五常稻花香（简单稻里）",
                  "stockCount": 9,
                  "saleCount": 52,
                  "headPic": "/staff-file/imageArt008.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 9,
                  "storeCode": "food03",
                  "categoryId": 1,
                  "category": null,
                  "item_name": "五常稻花香（恰到好处）",
                  "introduction": "",
                  "item_price": 79.0,
                  "discountPrice": 79.0,
                  "specification": "1袋*2.5kg",
                  "direction": null,
                  "searchKey": "五常稻花香（恰到好处）",
                  "stockCount": 18,
                  "saleCount": 51,
                  "headPic": "/staff-file/imageArt009.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              }
          ]
      },
      {
         "sub_menu_id": 2,
          "sub_menu_name": "零食干果",
          "sub_menu_code":"102",
          "sub_menu_img":"",
          "items": [
              {
                  "item_code": 14,
                  "storeCode": "food03",
                  "categoryId": 2,
                  "category": null,
                  "item_name": "好丽友薯愿薯片",
                  "introduction": "",
                  "item_price": 12.0,
                  "discountPrice": 12.0,
                  "specification": "1桶*104g",
                  "direction": null,
                  "searchKey": "好丽友薯愿薯片",
                  "stockCount": 14,
                  "saleCount": 52,
                  "headPic": "/staff-file/imageArt014.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 15,
                  "storeCode": "food03",
                  "categoryId": 2,
                  "category": null,
                  "item_name": "唇动",
                  "introduction": "",
                  "item_price": 16.0,
                  "discountPrice": 16.0,
                  "specification": "1盒*180g（6枚）",
                  "direction": null,
                  "searchKey": "唇动",
                  "stockCount": 2,
                  "saleCount": 51,
                  "headPic": "/staff-file/imageArt015.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 16,
                  "storeCode": "food03",
                  "categoryId": 2,
                  "category": null,
                  "item_name": "喜之郎果冻",
                  "introduction": "",
                  "item_price": 6.0,
                  "discountPrice": 6.0,
                  "specification": "1杯*200g",
                  "direction": null,
                  "searchKey": "喜之郎果冻",
                  "stockCount": 14,
                  "saleCount": 52,
                  "headPic": "/staff-file/imageArt016.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              }
          ]
      },
      {
        "sub_menu_id": 3,
        "sub_menu_name": "酒水饮料",
        "sub_menu_code":"102",
        "sub_menu_img":"",
          "items": [
              {
                  "item_code": 11,
                  "storeCode": "food03",
                  "categoryId": 3,
                  "category": null,
                  "item_name": "极致纯牛奶",
                  "introduction": "",
                  "item_price": 79.0,
                  "discountPrice": 79.0,
                  "specification": "1提*12盒*250ml",
                  "direction": null,
                  "searchKey": "极致纯牛奶",
                  "stockCount": 5,
                  "saleCount": 51,
                  "headPic": "/staff-file/imageArt011.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 12,
                  "storeCode": "food03",
                  "categoryId": 3,
                  "category": null,
                  "item_name": "特仑苏纯牛奶",
                  "introduction": "",
                  "item_price": 79.0,
                  "discountPrice": 79.0,
                  "specification": "1提*12盒*250ml",
                  "direction": null,
                  "searchKey": "特仑苏纯牛奶",
                  "stockCount": 7,
                  "saleCount": 51,
                  "headPic": "/staff-file/imageArt012.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              },
              {
                  "item_code": 13,
                  "storeCode": "food03",
                  "categoryId": 3,
                  "category": null,
                  "item_name": "蒙牛纯甄",
                  "introduction": "",
                  "item_price": 79.0,
                  "discountPrice": 79.0,
                  "specification": "1提*12盒*250ml",
                  "direction": null,
                  "searchKey": "蒙牛纯甄",
                  "stockCount": 5,
                  "saleCount": 51,
                  "headPic": "/staff-file/imageArt013.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              }
          ]
      },
      {
          "sub_menu_id": 4,
          "sub_menu_name": "蔬菜水果",
          "sub_menu_code":"102",
          "sub_menu_img":"",
          "items": [
              {
                  "item_code": 10,
                  "storeCode": "food03",
                  "categoryId": 4,
                  "category": null,
                  "item_name": "小农柴鸡蛋",
                  "introduction": "",
                  "item_price": 98.0,
                  "discountPrice": 98.0,
                  "specification": "1提*60枚",
                  "direction": null,
                  "searchKey": "小农柴鸡蛋",
                  "stockCount": 5,
                  "saleCount": 55,
                  "headPic": "/staff-file/imageArt010.png",
                  "salesReturn": 0,
                  "producer": "",
                  "level": 0,
                  "status": 0,
                  "picViewList": []
              }
          ]
      },
     ],
    contProHight:0,//商品列表部分的高度
    bottomHight:0,//底部部分占位的高度
    productList:[],//购物车
    isSearch:false,//是否开始搜索
   
    isEmpty:false,
    tipImg:"/images/emptyGoods.png",
    searchKey:"",//搜索关键字
    filterData:[],//搜索过滤后的数据
    cost:0,//总价
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //设置标题
    // wx.setNavigationBarTitle({
    //   title: '',
    // })
    let screenHeight =  wx.getSystemInfoSync().windowHeight;//可视区域整体高度
    utils.getRect('head',(res)=>{
      //获取头部的高度
       this.setData({
        headHeight:Math.ceil(res.height)
      })
      let contProHight = screenHeight - this.data.headHeight - this.data.footerHeight;  // 产品列表的高度
      this.setData({
        height: screenHeight,
        contProHight:contProHight
      })
      //请求列表数据
      this.getMenuItems()
    });
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow:function(){
    console.log(app.globalData.footerHeight)
    this.setData({
      productList:app.globalData.productList
    })
  },
   //请求列表数据
   request() {
      utils.getAllRects ('.pro-box',this.setAllFn)//获取列表高度：计算右侧每一个分类的高度，在数据请求成功后请求即可
      utils.getAllRects ('.pro-title',this.setleftFn);//获取左侧每个元素高度
  },
  //搜索
  search(e){
    this.setData({
      isSearch:e.detail?true:false,
      searchKey:e.detail
     })
     this.filterFn(e.detail)
    // console.log(this.data.searchKey) 
  },
  //搜索过滤方法
  filterFn(searchKey){
    console.log('监听搜索',searchKey)
    let filterData = [];
    let goodsList = utils.deepClone(this.data.sub_menus);
    console.log(goodsList)
       goodsList.forEach((item,index)=>{
            let obj = {
                sub_menu_id:item.sub_menu_id,
                sub_menu_name:item.sub_menu_name,
                sub_menu_code:item.sub_menu_code,
                items:[]
            }
        item.items.forEach((v,i)=>{ 
            if(v.item_name.indexOf(searchKey)!=-1){
                obj.items.push(v)
                let isSub = filterData.find(
                  item => item.sub_menu_code === obj.sub_menu_code
                );
                //如果删选得列表应该存在这个种类
                if(isSub){
                  isSub.push(v)
                }else{
                  filterData.push(obj)
                }
            }
        })

    })
    console.log('过滤数据',filterData)
    if(filterData.length==0){
       this.setData({
        isEmpty:true
       })
    }else{
      this.setData({ 
        filterData:filterData,
        isEmpty:false
      })
    }
     //获取购物车存贮的对应商品的数量赋值给列表
     this.initProlist()

},

filterFn1(searchKey){
  console.log('监听搜索',searchKey)
  let filterData = [];
  let goodsList = utils.deepClone(this.data.sub_menus);
  console.log(goodsList)
  goodsList.forEach((item,index)=>{
      item.items.forEach((v,i)=>{
          if(v.item_name.indexOf(searchKey)!=-1){
             filterData.push(v)
          }
      })
  })

  if(filterData.length==0){
     this.setData({
      isEmpty:true
     })
  }else{
    this.setData({ 
      filterData:filterData,
      isEmpty:false
    })
  }
   //获取购物车存贮的对应商品的数量赋值给列表
   this.initProlist()

},
  //减少购物车的商品
  decrease(e){
     console.log('当前商品',e.currentTarget.dataset)
        let goodsItem =  utils.deepClone(e.currentTarget.dataset.itemname); //点击的商品
        let sub_menu_id = e.currentTarget.dataset.typeId || "";
        goodsItem.count = goodsItem.count>0?--goodsItem.count:0;//改变数量
        // 如果当前商品数量为0则删除该商品
        if(goodsItem.count>0){
          this.changeNumber(goodsItem)
        }else{
          this.deleteGoods(goodsItem)
        }
   },
    //增加购物车的商品
    add(e){
        console.log('当前商品',e.currentTarget.dataset)
        let goodsItem =  utils.deepClone(e.currentTarget.dataset.itemname); //点击的商品
        let sub_menu_id = e.currentTarget.dataset.typeId || "";//当前商品的分类id
        goodsItem.count = ++goodsItem.count; //增加数量
        this.changeNumber(goodsItem)
    },

//改变购物车商品数量
 changeNumber(goodsItem){
      let proData = utils.deepClone(this.data.proData); //商品列表数据
     let shop = {
         shopCode: this.data.shopCode,
          shop_name: this.data.shop_name,
          cartList: [] //添加的商品的数组
      };
      shop.cartList.push(goodsItem);
        if(this.data.productList.length!=0){
            //如果购物车不为空
            //判断购物车是不是存在该店铺，如果存在该店铺则返回该店铺
            let shopInfomation = this.data.productList.find(
                item => item.shopCode === shop.shopCode
            );
            //如果存在该店铺
            if (shopInfomation) {
              //判断该店铺是否存在该商品，如果存在则但会该商品
                const product = shopInfomation.cartList.find(
                    item => item.item_code === shop.cartList[0].item_code
                );
                 if (product) {
                    //如果购物车有这个商品
                    //修改count
                    product.count = shop.cartList[0].count;
                } else {
                  //如果不存在则直接push
                    shopInfomation.cartList.push(shop.cartList[0]);
                }
              
            } else {
              //如果购物车不存在该店铺
                 this.data.productList.push(shop);
            }
        }else{
            this.data.productList.push(shop);
        }
        app.globalData.productList = this.data.productList;
          //对应商品的数量赋值给列表
         this.costAll(this.data.productList);//计算总价
        this.initProlist();
        // 保存到本地
        //  wx.setStorageSync('productList', JSON.stringify( this.data.productList));
 },

//如果该商品数量为0则删除购物车该商品，如果购物车中该店铺的所有商品为0，则删除整个店铺
  deleteGoods(goodsItem){
   let sub_menus = utils.deepClone(this.data.sub_menus); //商品列表数据
      if(this.data.productList.length!=0){
            //如果购物车不为空
          //判断购物车是不是存在该店铺，如果存在该店铺则返回该店铺
          let shopInfomation = this.data.productList.find(
            item => item.shopCode === this.data.shopCode
        );
            //如果存在该店铺
          if (shopInfomation) {
            //判断该店铺是否存在该商品，如果存在则删除该商品
              const product = shopInfomation.cartList.find(
                  item => item.item_code === goodsItem.item_code
              );
              console.log('减少')
                if (product) {
                  //如果购物车有这个商品，则移除该商品
                    let goodsIndex = shopInfomation.cartList.findIndex(
                        item => item.item_code === product.item_code
                    );
                    shopInfomation.cartList.splice(goodsIndex, 1);
                   console.log(shopInfomation.cartList,'shan除数据')
                  //如果当前店铺的所有商品都删除了，则把当前店铺从购物车里移除
                    if (shopInfomation.cartList.length == 0) {
                      let index = this.data.productList.findIndex(
                          item => item.shopCode === shopInfomation.shopCode
                      );
                      this.data.productList.splice(index, 1)
                        //对应商品的数量赋值给列表
                   }
                   console.log(this.data.productList)
                    app.globalData.productList = this.data.productList;
                    this.costAll(this.data.productList);//计算总价
                   this.initProlist();
                  //  wx.setStorageSync('productList', JSON.stringify( this.data.productList));
              }

          } 
    }
  
},


//初始化列表数据和购物车数据作对比
  initProlist(){
    let sub_menus;
    if(this.data.isSearch){
      //如果是搜索
      sub_menus = utils.deepClone(this.data.filterData)
    }else{
      sub_menus = utils.deepClone(this.data.sub_menus)
    }
     for(let i=0;i< sub_menus.length;i++){
       for(let j=0;j<sub_menus[i].items.length;j++){
           let goodsItem = sub_menus[i].items[j];
                if (this.data.productList.length != 0) {
                    let shopInfomation = this.data.productList.find(
                        item => item.shopCode === this.data.shopCode
                    );
                    if (shopInfomation) {
                      //如果购物车存在该店铺
                        if (shopInfomation.cartList.length != 0) {
                          //判断购物车里的该店铺是否存在该商品
                            const isAdded = shopInfomation.cartList.find(
                                item => item.item_code === goodsItem.item_code
                            );
                            //如果购物车存在当前商品
                            if (isAdded) {
                              // 则在列表中找到对应的该商品然后把count赋值给该商品
                                 sub_menus[i].items[j].count = isAdded.count;
                                console.log( sub_menus,'初始化数据')
                            }else{
                                sub_menus[i].items[j].count = 0;
                            }
                          
                        }
                    }else{
                        sub_menus[i].items[j].count = 0;
                    }
                } else {
                   sub_menus[i].items[j].count = 0;      
                }   
          } 
      }
      if(this.data.isSearch){
        //如果是搜索
        this.setData({
          filterData:sub_menus
        })
      }else{
          this.setData({
            sub_menus:sub_menus
          })
      }
      
  },

  //获取当前菜单
  getMenuItems(){
    let that = this;
      httpUtil.requestApi({
        url: app.globalData.baseUrlOrder+"mealCodeOrder/getMenuItems",
        header: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        method:"POST",
        data: {
            shopCode: that.data.shopCode
        },
      success(resData) {
        if(resData.data&&resData.data.code==0){
          that.setData({
            proData: resData.data.menus[0],
            shop_name:resData.data.shop_name,
            sub_menus:resData.data.menus[0].sub_menus
          })
          utils.getAllRects ('.pro-box',that.setAllFn)//获取列表高度：计算右侧每一个分类的高度，在数据请求成功后请求即可
          utils.getAllRects ('.pro-title',that.setleftFn);//获取左侧每个元素高度
           //获取购物车存贮的对应商品的数量赋值给列表
           that.initProlist()
        }else{
              that.setData({
                isEmpty:true
              })
        }   
      }
    })
  },

  //去下单
  handle(){
     wx.redirectTo({
       url: this.data.orderBaseUrl+'/pages/shopCart/shopCart',
     })
  },
  // 计算总价
  costAll(productList){
    let cost = 0;
    if (this.data.productList.length != 0) {
      let shopInfomation = this.data.productList.find(
          item => item.shopCode === this.data.shopCode
      );
      if (shopInfomation) {
        //如果购物车存在该店铺
          if (shopInfomation.cartList.length != 0) {
            let cartList = shopInfomation.cartList;
            cartList.forEach(item => {
                cost += item.count * item.item_price;
            });
          }
      }
  } 
      this.setData({
        cost: cost.toFixed(2)
      })
      return cost.toFixed(2);
  },


  // 基础事件
  //点击左侧元素事件
  proItemTap(e) {
    this.distanceLeft = this.data.leftMenuHight*e.currentTarget.dataset.pos;//记录此时左侧距离可视区域顶部的距离
    if(Math.ceil(this.distanceLeft)>this.data.contProHight || this.data.leftscrollTop >this.heightLeftArr[0]){
      //当前点击的左侧元素距离顶部的距离大于可视区域的距离或者此时左边的scrollTop大于-leftMenuHight，则让左侧的scrollTop为随当前点击的左侧元素距离顶部的距离
        this.setData({
          leftscrollTop:this.heightLeftArr[e.currentTarget.dataset.pos-1]
        })
    }
    //左侧选择项目点击事件 currentLeft：控制左侧选中样式  selectId：设置右侧应显示在顶部的id
    this.setData({
      currentLeft: e.currentTarget.dataset.pos,
      selectId: "item" + e.currentTarget.dataset.pos
    })
  },
  //监听scroll-view的滚动事件
  scrollEvent(event) {
    // console.log("滚动")
    if (this.heightArr.length == 0) {
        return;
    }
    let scrollTop = Math.ceil(event.detail.scrollTop);
    let current = this.data.currentLeft;
    if (scrollTop >= this.distance) { //页面向上滑动
      //如果右侧当前可视区域最底部到顶部的距离超过当前列表选中项距顶部的高度（且没有下标越界），则更新左侧选中项
      if (current + 1 <= this.heightArr.length && scrollTop >= this.heightArr[current]) {
        this.setData({
          currentLeft: current + 1
        })
        /*  
          当前左侧选中项距可视区域顶部的距离大于左侧可视区域的距离，则更改左侧的scrollTop值
           console.log(this.data.leftMenuHight*(this.data.currentLeft+1),'左侧选中项距可视区域顶部的距离(+1是因为下标是从0开始)')
           注意：左侧的menu高度不固定，则需要动态获取高度:this.heightLeftArr[index]
           60是底部tab的距离，因为是自定义的tabBar就会存在这个问题，如果是自定义的则不会存在这个问题
        */
        if(this.heightLeftArr[this.data.currentLeft]>this.data.contProHight-60){
          console.log('到底了')
          this.setData({
              leftscrollTop:this.heightLeftArr[this.data.currentLeft]
          })
        } 
      }
    } else { //页面向下滑动
      //如果右侧当前可视区域最顶部到顶部的距离 小于 当前列表选中的项距顶部的高度，则更新左侧选中项
      if (current - 1 >= 0 && scrollTop < this.heightArr[current - 1]) {
         this.setData({
          currentLeft: current - 1,
        })
        //左侧距离可视区域顶部的距离如果大于0，则则更新左侧scrollTop的值，使左侧项目向上滚动
        // console.log(this.distanceLeft,'距离顶顶')
        // console.log(this.data.leftscrollTop,'距离顶顶233')
       // console.log('数组',(this.data.currentLeft-1),this.heightLeftArr[this.data.currentLeft-1])
        if(this.distanceLeft>0){
          //下表越界判断this.data.currentLeft>0
            this.setData({
                leftscrollTop:this.data.currentLeft>0?this.heightLeftArr[this.data.currentLeft-1]:0
            })
        }
      }
    }
    //更新到顶部的距离
    this.distance = scrollTop;//重新设置右侧距离顶部的距离
    this.distanceLeft = this.data.leftscrollTop;//重新设置左侧距离顶部的距离
  },
  //选中符合条件所有dom元素的回调函数
  setAllFn(...res){
    // console.log(res)
     let h = 0;
    res[0].forEach((item) => {
      h += item.height;
      this.heightArr.push(h);
    })
  },
//获取左侧每个元素的高度：
setleftFn(...res){
  // console.log(res)
  let h=0;
  res[0].forEach((item) => {
     h+=item.height;
     this.heightLeftArr.push(h);
      this.setData({
        leftMenuHight:Math.ceil(item.height)
      })
  })
},


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})