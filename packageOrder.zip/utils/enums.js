export const enums = {
  elementlist: [
  "image",
  "text",
  "button",
  "input",
  "textarea",
  "formbutton"
  ],
  staticproplist: [
  "data"
  ],
  heightnavmode: [
  "iPhone X"
  ]
  }