// components/empty/empty.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    tipMsg:{
      type:String,
      value:""
    },
    isBtn:{
      type:Boolean,
      default:false
    },
    tipImg:{
      type:String,
      default:""
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    handle(){
      this.triggerEvent('handle')
    }
  }
})
