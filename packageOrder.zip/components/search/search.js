// components/search/search.js
const utils = require('./../../utils/util.js'); //接口和key文件
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    searchheight:{
      type:Number,
      value:300
    },
    filterData:{
        type:Array,
        value:[]
    },

    
  },

  attached: function() {
    // 在组件实例进入页面节点树时执行
    
  },
  /**
   * 组件的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
