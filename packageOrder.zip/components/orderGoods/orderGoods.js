// components/goodsCart/goodsCart.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    itemName:{
      type:Object,
      value:{}
    },
    idx:{
      type:Number,
      value:0
    },
    index:{
      type:Number,
      value:0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
