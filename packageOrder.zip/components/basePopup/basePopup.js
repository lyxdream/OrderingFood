// components/CustomPopup/CustomPopup.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  options:{
    multipleSlots:true  //启用slot插槽
  },
  properties: {
    showCustomPopup:{
      type: Boolean,
      value: false,
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
