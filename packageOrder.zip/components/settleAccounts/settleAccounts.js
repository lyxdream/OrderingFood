// components/settleAccounts/settleAccounts.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    operationName:{
      type:String,
      value:""
    },
    cost:{
      type:Number,
      default:0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
    footerHeight: app.globalData.footerHeight,//底部的高度
  },

  /**
   * 组件的方法列表
   */
  methods: {
    handle(){
      this.triggerEvent('handle')
    }
  }
})
