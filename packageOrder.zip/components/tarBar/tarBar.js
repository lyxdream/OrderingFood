const app = getApp();
Component({
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
    tabBar:{
      selected: 0,
      color: "#cccccc",
      selectedColor: "#F5A019",
      list: [{
        pagePath: "/packageOrder/pages/home/home",
        iconPath: app.globalData.orderBaseImg+"/images/home.png",
        selectedIconPath: app.globalData.orderBaseImg+"/images/homeCurr.png",
        text: "首页",
        isSpecial: false,
        active: true
      }, {
        pagePath: "/packageOrder/pages/shopCart/shopCart",
        iconPath: app.globalData.orderBaseImg+"/images/cart.png",
        selectedIconPath: app.globalData.orderBaseImg+"/images/cartCurr.png",
        text: "购物车",
        isSpecial: false,
        active: false
      }, {
        pagePath: "/packageOrder/pages/orderList/orderList",
        iconPath: app.globalData.orderBaseImg+"/images/order.png",
        selectedIconPath:app.globalData.orderBaseImg+ "/images/orderCurr.png",
        text: "订单",
        isSpecial: false,
        active: false
      }],
    },

    //适配IphoneX的屏幕底部横线
    footerHeight:app.globalData.footerHeight,
  },
  attached() {
    this.editTabBar();    //显示自定义的底部导航
  },
  methods: {
    switchTab(e) {
      const dataset = e.currentTarget.dataset
      const path = dataset.path
      const index = dataset.index
      //如果是特殊跳转界面
      let tabBar = this.data.tabBar;
      tabBar.selected= index; 
        this.setData({
            tabBar: tabBar
        })
        wx.redirectTo({
          url: path
        })
    },
    editTabBar: function () {
      //使用getCurrentPages可以获取当前加载中所有的页面对象的一个数组，数组最后一个就是当前页面。
      var curPageArr = getCurrentPages();    //获取加载的页面
      var curPage = curPageArr[curPageArr.length - 1];    //获取当前页面的对象
      var pagePath = curPage.route;    //当前页面url
      console.log('当前页面url'+pagePath)
      if (pagePath.indexOf('/') != 0) {
        pagePath = '/' + pagePath;
      }
      var tabBar = this.data.tabBar;
      for (let i = 0; i < tabBar.list.length; i++) {
        if(pagePath=='/packageOrder/pages/settlement/settlement'){
           tabBar.selected= 1;
        }else if (tabBar.list[i].pagePath == pagePath) {
           tabBar.selected= i;    //根据页面地址设置当前页面状态    
           console.log(tabBar)
        }
      }
      this.setData({
        tabBar: tabBar
      });
    },
  



  }
})
