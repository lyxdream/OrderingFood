// components/couponPup/couponPup.js
const app = getApp();
Component({
  options: {
      multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    orderBaseImg:app.globalData.orderBaseImg,
    descClause:"描述，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，描述，，，，，，，，，，"
  },
  attached(){
  
  },
  /**
   * 组件的方法列表
   */
  methods: {
    close(){
      this.triggerEvent('close')
    }
  }
})
