// components/orderNumber/orderNumber.js
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
      orderBaseImg:app.globalData.orderBaseImg,
     showCustomPopup:true,
     listNumber:[1,2,3,4,5,6,7,8,9,10],
     number:1
  },

  /**
   * 组件的方法列表
   */
  methods: {
    maskClick(){
      this.triggerEvent('maskClick')
    },
    //确定
    confirm(){
       this.triggerEvent("confirm",this.data.number)
    },
    //选择人数
    selectNum(e){
        // console.log(e.currentTarget.dataset)
        let item = e.currentTarget.dataset.item;
        this.setData({
          number:item
        })
    }
  }
})
